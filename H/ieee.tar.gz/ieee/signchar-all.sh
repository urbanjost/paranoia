#! /bin/sh
### ====================================================================
### Test all known C and C++ compilers for wchar_t data type support
### characteristics, and test lcc with signed and unsigned char data
### type.
### [09-May-2001]
### ====================================================================

LIBDIR=`dirname $0`
trap '/bin/rm -f wchar.o a.out'

mywhich()
{
	for d in ` echo $PATH | sed -e 's/:/ /g' `
	do
		test -f $d/$1 && echo $d/$1 && return
	done
	echo ""
}

LCC=`mywhich lcc`

echo ========================================================================
if test -n "$LCC"
then
	echo Testing $LCC -Wf-unsigned_char=0
	/bin/rm -f a.out &&
		$LCC -Wf-unsigned_char=0 $LIBDIR/signchar.c &&
		./a.out &&
		/bin/rm -f a.out
	echo ------------------------------------------------------------------------
	echo Testing $LCC -Wf-unsigned_char=1
	/bin/rm -f a.out &&
		$LCC -Wf-unsigned_char=1 $LIBDIR/signchar.c &&
		./a.out &&
		/bin/rm -f a.out
	echo ------------------------------------------------------------------------
fi

for compiler in c89 cc cc128 CC "cxx -x cxx" c++ xlc xlc128 xlC xlC128 gcc g++ pgcc pgCC sgicc sgiCC DCC NCC
do
	CC=`mywhich $compiler`
	if test -n "$CC"
	then
		echo Testing $CC
		/bin/rm -f a.out &&
			$CC $LIBDIR/signchar.c &&
			./a.out &&
			/bin/rm -f a.out
		echo ------------------------------------------------------------------------
	fi
done
echo ========================================================================
