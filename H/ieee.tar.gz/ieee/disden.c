#include "ieeeftn.h"

#if STDC
LOGICAL
disden(DOUBLEPRECISION *x)
#else /* NOT STDC */
LOGICAL
disden(x)			/* return (x is denormalized) */
DOUBLEPRECISION	*x;
#endif /* STDC */
{
    return (dintxp(x) <= EXPONENT_DENORM_DP) ? _TRUE_ : _FALSE_;
}
