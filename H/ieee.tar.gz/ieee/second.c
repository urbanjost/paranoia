#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>

#if defined(__alpha)
#include <time.h>
#define HZ	CLK_TCK
#endif

#include "ieeeftn.h"

#if __convex__
#include <time.h>
#if !defined(HZ) && defined(CLOCKS_PER_SEC)
#define HZ CLOCKS_PER_SEC
#endif
#if !defined(HZ) && defined(CLK_TCK)
#define HZ CLK_TCK
#endif
#endif /* __convex__ */

#if STDC
#include <unistd.h>
#endif

#ifndef HZ
#ifdef AHZ
#define HZ AHZ				/* NeXT (CMU MACH O/S) uses AHZ */
#else
#define HZ 60
#endif
#endif

double
second(VOID_ARG)
{
    struct tms buffer;

    (void)times(&buffer);
    return((double)(buffer.tms_utime + buffer.tms_stime)/(double)(HZ));
}
