#! /bin/sh
if test `uname -s` = "AIX"
then
	MODEL=ppcaix
elif test `uname -s` = "HP-UX"
then
	MODEL=pa-risc
else
	MODEL=`uname -m | sed -e 's/ /_/g' `
fi

OS=`uname -s`

NTIMES=1000000
TIMOPS="./timops $NTIMES ; ./timops $NTIMES  ; ./timops $NTIMES"
TARGETS='clean timops'

case "$MODEL" in
alpha)
	case "$OS" in
	Linux)
		make CC=gcc CDEFINES='-DFP_T_FLOAT -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
		make CC=gcc CDEFINES='-DFP_T_FLOAT -mieee' $TARGETS && $TIMOPS
		make CC=gcc CDEFINES='-DFP_T_DOUBLE -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
		make CC=gcc CDEFINES='-DFP_T_DOUBLE -mieee' $TARGETS && $TIMOPS
		case `uname -r` in
		V5*)
			make CC=gcc CDEFINES='-DFP_T_LONG_DOUBLE -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
			make CC=gcc CDEFINES='-DFP_T_LONG_DOUBLE -mieee' $TARGETS && $TIMOPS
			;;
		*)
			;;
		esac
		;;
	OSF1)
		make CC=c89 CDEFINES='-DFP_T_FLOAT -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
		make CC=c89 CDEFINES='-DFP_T_FLOAT -ieee' $TARGETS && $TIMOPS
		make CC=c89 CDEFINES='-DFP_T_DOUBLE -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
		make CC=c89 CDEFINES='-DFP_T_DOUBLE -ieee' $TARGETS && $TIMOPS
		case `uname -r` in
		V5*)
			make CC=c89 CDEFINES='-DFP_T_LONG_DOUBLE -DSKIP_INF -DSKIP_NAN -DSKIP_OFL' $TARGETS && $TIMOPS
			make CC=c89 CDEFINES='-DFP_T_LONG_DOUBLE -ieee' $TARGETS && $TIMOPS
			;;
		*)
			;;
		esac
		;;
	*)
		echo "Cannot recognize O/S = " $OS
		echo "uname -m = `uname -m`"
		echo "uname -s = `uname -s`"
		exit 1
	esac
	;;
i386 | i486 | i586 | i686 )
	make CC=gcc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=gcc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=gcc CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
ia64)
	make CC=gcc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=gcc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=gcc CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
IP22 | IP27 | IP32 | IP64)
	make CC=c89 CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=c89 CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=c89 CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
pa-risc)
	make CC=cc COPT= CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=cc COPT= CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=cc COPT= CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
ppcaix)
	make CC=cc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_LONG_DOUBLE -qlongdouble' $TARGETS && $TIMOPS
	;;
ppc)
	make CC=cc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
Power_Macintosh)
	make CC=cc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
sun*)
	make CC=c89 CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=c89 CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=c89 CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
sparc*)
	make CC=cc CDEFINES='-DFP_T_FLOAT' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_DOUBLE' $TARGETS && $TIMOPS
	make CC=cc CDEFINES='-DFP_T_LONG_DOUBLE' $TARGETS && $TIMOPS
	;;
*)
	echo "Cannot recognize MODEL = " $MODEL
	echo "uname -m = `uname -m`"
	echo "uname -s = `uname -s`"
	exit 1
esac
