#include "ieeeftn.h"

#if STDC
LOGICAL
disinf(DOUBLEPRECISION *x)
#else /* NOT STDC */
LOGICAL
disinf(x)
DOUBLEPRECISION *x;
#endif /* STDC */
{
    DOUBLEPRECISION_PARTS w;

    w.r = *x;
    return (((GET_EXPONENT_DP(w.i[DP_HIGH]) == EXPONENT_INFNAN_DP) &&
	     (SIGNIFICAND_DP(w.i[DP_HIGH]) == 0) && (w.i[DP_LOW] == 0))
	    ? _TRUE_ : _FALSE_);
}
