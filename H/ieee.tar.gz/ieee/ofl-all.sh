#! /bin/sh
### ====================================================================
### Run the ofl tests with all known C and C++ compilers.
### [20-Apr-2001]
### ====================================================================
LIBDIR=`dirname $0`
echo LIBDIR = $LIBDIR
for f in c89 cc cc128 CC "cxx -x cxx" c++ xlc xlc128 xlC xlC128 gcc g++ pgcc pgCC sgicc sgiCC DCC NCC
do
	echo =========== $f
	env CC=$f $LIBDIR/ofl.sh -DHAVE_LONG_LONG -DHAVE_LONG_DOUBLE
done
