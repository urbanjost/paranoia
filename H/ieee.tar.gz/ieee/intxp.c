#include "ieeeftn.h"

#if STDC
INTEGER
intxp(REAL *x)
#else /* NOT STDC */
INTEGER
intxp(x) /* return the exponent of the base in the representation of x */
REAL *x;
#endif /* STDC */
{
    REAL_PARTS w;
    register INTEGER e;

    w.r = *x;
    e = GET_EXPONENT_SP(w.i);

    if (*x == 0.0)			/* handle zero specially */
	e = 0;
    else if (e == EXPONENT_DENORM_SP)	/* have denormalized number */
    {
	w.r *= BASE_TO_THE_T_SP;	/* make normal number */
	e = GET_EXPONENT_SP(w.i) - T_SP;
    }
    return (e);
}
