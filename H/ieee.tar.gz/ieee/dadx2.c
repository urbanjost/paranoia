#include "ieeeftn.h"

#if STDC
DOUBLEPRECISION
dadx(DOUBLEPRECISION *x, INTEGER *n)
#else /* NOT STDC */
DOUBLEPRECISION
dadx(x,n)				/* return x * base**n */
DOUBLEPRECISION *x;
INTEGER *n;
#endif /* STDC */
{
    INTEGER delta_e;
    INTEGER e;
    DOUBLEPRECISION_PARTS w;
    DOUBLEPRECISION new_x;

    w.r = *x;
    e = GET_EXPONENT_DP(w.i[DP_HIGH]);		/* extract old exponent */

    if (*x == 0.0)			/* zero remains unchanged */
	/* NO-OP */;
    else if (e == EXPONENT_INFNAN_DP)	/* original number is NaN or Inf */
	/* NO-OP */;			/* so no change in value */
    else if (e == EXPONENT_DENORM_DP)	/* original number is denormalized */
    {
	delta_e = *n - T_DP;
	new_x = *x * BASE_TO_THE_T_DP;	/* scale into normal range */
	w.r = dadx(&new_x, &delta_e);
    }
    else				/* original number is normal */
    {
	e += *n;			/* new exponent */
	w.r = dsetxp(x,&e);
    }
    return (w.r);
}
