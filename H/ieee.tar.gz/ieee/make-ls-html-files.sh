#! /bin/sh
ls -lRt | awk -f lstohtml.awk -v INDENT=1 -v PREFIX=http://www.math.utah.edu/~beebe/software/ieee/ > ls-lRt.html
ls -lR | awk -f lstohtml.awk -v INDENT=1 -v PREFIX=http://www.math.utah.edu/~beebe/software/ieee/ >  ls-lR.html
