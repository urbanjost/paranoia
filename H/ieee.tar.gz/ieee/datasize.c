/***********************************************************************
[21-Mar-2001]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "args.h"

int
main(VOID_ARG)
{
    (void)printf("Pointer sizes...\n");
    (void)printf("\tsizeof(char*)        \t= %d\n", (int)sizeof(char*));
    (void)printf("\tsizeof(void*)        \t= %d\n", (int)sizeof(void*));
    (void)printf("\tsizeof(void(*)(void))\t= %d\n", (int)sizeof(void(*)(VOID_ARG)));
    (void)printf("\n\n");
    (void)printf("Integer sizes...\n");
    (void)printf("\tsizeof(char)         \t= %d\n", (int)sizeof(char));
    (void)printf("\tsizeof(short)        \t= %d\n", (int)sizeof(short));
    (void)printf("\tsizeof(int)          \t= %d\n", (int)sizeof(int));
    (void)printf("\tsizeof(long)         \t= %d\n", (int)sizeof(long));

#if defined(HAVE_LONG_LONG)
    (void)printf("\tsizeof(long long)    \t= %d\n", (int)sizeof(long long));
#endif

    (void)printf("\n\n");
    (void)printf("Floating-point sizes...\n");
    (void)printf("\tsizeof(float)        \t= %d\n", (int)sizeof(float));
    (void)printf("\tsizeof(double)       \t= %d\n", (int)sizeof(double));

#if defined(HAVE_LONG_DOUBLE)
    (void)printf("\tsizeof(long double)  \t= %d\n", (int)sizeof(long double));
#endif

    return (EXIT_SUCCESS);
}
