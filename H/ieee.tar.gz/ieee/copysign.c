/***********************************************************************
C program to test the IEEE 754 copysign() function.  That function is
not part of 1989 Standard C, so this program will not work on some
systems.
[10-Oct-2001]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "args.h"

int
main(VOID_ARG)
{
    double x,y;

    x = copysign(0.0,-1.0);
    y = copysign(0.0,1.0);
    (void)printf("-0 > +0: %s\n", (x > y) ? "TRUE" : "FALSE");
    (void)printf("-0 < +0: %s\n", (x < y) ? "TRUE" : "FALSE");
    (void)printf("-0 == +0: %s\n", (x == y) ? "TRUE" : "FALSE");
    (void)printf("-0 == +0: %s\n", (x == y) ? "TRUE" : "FALSE");
    (void)printf("copysign(0,-1) = %f\n", copysign(0.0,-1.0));
    (void)printf("copysign(0,1) = %f\n", copysign(0.0,1.0));

    return (EXIT_SUCCESS);
}
