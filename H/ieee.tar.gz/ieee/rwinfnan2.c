/***********************************************************************
[22-Nov-2001]
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "args.h"

#define is_nan(arg)	(arg != arg)
#define is_ninf(arg)	(arg == -Inf)
#define is_pinf(arg)	(arg == Inf)

static float NaN, Inf;

int
main(VOID_ARG)
{
    char line[50];
    float s, x;
    FILE *fp;

    fp = fopen("rwinfnan2.tmp","w+");
    if (fp == (FILE*)NULL)
	exit(EXIT_FAILURE);

    s = (float)0.0;
    x = s;
    Inf = (float)1.0/s;
    NaN = x/s;

    (void)fprintf(fp, "%g\n", NaN);
    (void)fprintf(fp, "%g\n", Inf);

    rewind(fp);
    (void)fgets(line, sizeof(line), fp);
    (void)printf("NaN was written as: %s", line);
    (void)fgets(line, sizeof(line), fp);
    (void)printf("Inf was written as: %s", line);

    rewind(fp);
    (void)fscanf(fp,"%g\n", &x);
    if (is_nan(x))
	(void)printf("NaN was correctly input as   0x%08x %g\n", *(unsigned int*)&x, (double)x);
    else
	(void)printf("NaN was INCORRECTLY input as 0x%08x %g\n", *(unsigned int*)&x, (double)x);

    (void)fscanf(fp,"%g\n", &x);
    if (is_pinf(x))
	(void)printf("Inf was correctly input as   0x%08x %g\n", *(unsigned int*)&x, (double)x);
    else
	(void)printf("Inf was INCORRECTLY input as 0x%08x %g\n", *(unsigned int*)&x, (double)x);

    return (EXIT_SUCCESS);
}
