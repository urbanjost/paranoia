#include <stdio.h>
#include <limits.h>
#include "args.h"

int main(VOID_ARG)
{
    (void)printf("(int)(unsigned)((char)0x7f))\t= %d\n", (int)(unsigned)((char)0x7f));
    (void)printf("(int)((char)0x7f))          \t= %d\n", (int)((char)0x7f));

    (void)printf("(int)(unsigned)((char)0xff))\t= %d\n", (int)(unsigned)((char)0xff));
    (void)printf("(int)((char)0xff))          \t= %d\n", (int)((char)0xff));

    (void)printf("CHAR_BIT\t= %d\n",	(int)CHAR_BIT);
    (void)printf("\n");

    (void)printf("CHAR_MIN\t= %d\n",	(int)CHAR_MIN);
    (void)printf("CHAR_MAX\t= %d\n",	(int)CHAR_MAX);
    (void)printf("char is %s\n", (CHAR_MIN < 0) ? "signed" : "unsigned");
    if ( ((CHAR_MIN < 0) && ((int)((char)0xff) >= 0)) ||
	 ((CHAR_MIN >= 0) && ((int)((char)0xff) < 0)) )
	(void)printf("ERROR: compiler and <limits.h> handle signed char differently!\n");
    (void)printf("\n");

    (void)printf("SCHAR_MIN\t= %d\n",	(int)SCHAR_MIN);
    (void)printf("SCHAR_MAX\t= %d\n",	(int)SCHAR_MAX);
    (void)printf("\n");

    (void)printf("UCHAR_MAX\t= %d\n",	(int)UCHAR_MAX);

    return(0);
}
