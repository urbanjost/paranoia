#include "ieeeftn.h"

#if STDC
LOGICAL
disnan(DOUBLEPRECISION *x)
#else /* NOT STDC */
LOGICAL
disnan(x)
DOUBLEPRECISION *x;
#endif /* STDC */
{
#if defined(__alpha)
    if (disden(x))
	return (_FALSE_);
    else
	return ((*x != *x) ? _TRUE_ : _FALSE_);
#else
    return ((*x != *x) ? _TRUE_ : _FALSE_);
#endif
}
