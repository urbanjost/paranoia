#include "ieeeftn.h"

#if STDC
INTEGER
dintxp(DOUBLEPRECISION *x)
#else /* NOT STDC */
INTEGER
dintxp(x) /* return the exponent of the base in the representation of x */
DOUBLEPRECISION *x;
#endif /* STDC */
{
    DOUBLEPRECISION_PARTS w;
    register INTEGER e;

    w.r = *x;
    e = GET_EXPONENT_DP(w.i[DP_HIGH]);

    if (*x == 0.0)			/* handle zero specially */
	e = 0;
    else if (e == EXPONENT_DENORM_DP)	/* have denormalized number */
    {
	w.r *= BASE_TO_THE_T_DP;	/* make normal number */
	e = GET_EXPONENT_DP(w.i[DP_HIGH]) - T_DP;
    }
    return (e);
}
