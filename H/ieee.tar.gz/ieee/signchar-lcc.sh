#! /bin/sh
# Test lcc with signed and unsigned char data type.
# [20-Mar-2001]

LIBDIR=`dirname $0`
trap '/bin/rm -f signchar.o a.out'

echo ========================================================================
/bin/rm -f a.out &&
	 lcc -Wf-unsigned_char=0 $LIBDIR/signchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ------------------------------------------------------------------------
/bin/rm -f a.out &&
	 lcc -Wf-unsigned_char=1 $LIBDIR/signchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ========================================================================
