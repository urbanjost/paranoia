// This program can be compiled with g++, but not by other C++ compilers,
// sigh..
// [22-Nov-2001]

// #include <ostream>
#include <iostream.h>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cstring>
// #include <string.h>

static float NaN, Inf;

static inline bool is_nan(float x)	{ return (x != x); }
static inline bool is_ninf(float x)	{ return (x == -Inf); }
static inline bool is_pinf(float x)	{ return (x == Inf); }
static inline bool is_inf(float x)	{ return (is_pinf(x) || is_ninf(x)); }

void error(const char *p, const char *p2 = "")
{
    cerr << p << ' ' << p2 << endl;
    std::exit(EXIT_FAILURE);
}

static const char* TMPFILE = "rwinfnan3.tmp";

void check_line(void)
{
    std::string line;
    std::ifstream fpin(TMPFILE);

    if (!fpin)
      error("cannot open input file",TMPFILE);

    fpin >> line;
    cout << "NaN was written as: " << line << endl;

    fpin >> line;
    cout << "Inf was written as: " << line << endl;

    fpin.close();
}

void check_InfNaN(void)
{
    float x;
    std::ifstream fpin(TMPFILE);

    if (!fpin)
      error("cannot open input file",TMPFILE);

    x = 999.0F;

    fpin >> x;
    cout << "NaN was read as: " << x << (is_nan(x) ? " [correct]" : " [INCORRECT]") << endl;

    fpin >> x;
    cout << "Inf was read as: " << x << (is_inf(x) ? " [correct]" : " [INCORRECT]") << endl;

    fpin.close();
}

int
main(void)
{
    float s, x;
    std::ofstream fpout(TMPFILE);

    if (!fpout)
      error("cannot open output file",TMPFILE);

    s = 0.0F;
    x = s;
    Inf = 1.0F/s;
    NaN = x/s;

    fpout << NaN << endl;
    fpout << Inf << endl;

    fpout.close();

    check_line();
    check_InfNaN();
    return (EXIT_SUCCESS);
}
