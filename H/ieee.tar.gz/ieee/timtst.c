/***********************************************************************
Time the floating-point primitives.
[20-Feb-1994]
***********************************************************************/

#include <stdio.h>
#include "ieeeftn.h"


int	main ARGS((int argc, char* argv[]));
double	second ARGS((void));

#define SHOW(funcall,str) { \
		   for (k = 1, t1 = second(); k <= n; ++k) \
		       (void)funcall; \
		   t2 = 1000000.0 * (second() - t1)/(double)n; \
		   printf("%s\t:%10.2lf microsec/call\n",str,t2); \
	       }

#if STDC
int
main(int argc,char* argv[])
#else /* NOT STDC */
int
main(argc,argv)
int argc;
char* argv[];
#endif /* STDC */
{
    double t1, t2;
    REAL r = 23.0;
    DOUBLEPRECISION d = 23.0;
    long n = (argc < 2) ? 100000 : atoi(argv[1]);
    long k;
    INTEGER e = 13;

    SHOW(dadx(&d,&e), "dadx");
    SHOW(dintxp(&d), "dintxp");
    SHOW(disden(&d), "disden");
    SHOW(disinf(&d), "disinf");
    SHOW(disnan(&d), "disnan");
    SHOW(dsetxp(&d,&e), "dsetxp");

    SHOW(adx(&r,&e), "adx");
    SHOW(intxp(&r), "intxp");
    SHOW(isden(&r), "isden");
    SHOW(isinf(&r), "isinf");
    SHOW(isnan(&r), "isnan");
    SHOW(setxp(&r,&e), "setxp");

    exit (EXIT_SUCCESS);
    return (EXIT_SUCCESS);
}
