#include <stdio.h>
#include <stddef.h>
#include "args.h"

int main(VOID_ARG)
{
    (void)printf("Wide character support...\n");
    (void)printf("\tsizeof(wchar_t*)     \t= %d\n", (int)sizeof(wchar_t*));
    (void)printf("\tsizeof(wchar_t)      \t= %d\n", (int)sizeof(wchar_t));
    (void)printf("wchar_t is %s\n", ((wchar_t)(-1) < (wchar_t)(0)) ? "signed" : "unsigned");
    return(0);
}
