#include "ieeeftn.h"

#if STDC
REAL
eps(REAL *x)
#else /* NOT STDC */
REAL
eps(x)
REAL	*x;
#endif /* STDC */
{
    REAL	half = 0.5;
    INTEGER	n = intxp(x) - T_SP;
    INTEGER	zero = 0;
    REAL_PARTS	w;

    if ( (*x == 0.0) || isden(x) )
    {
	w.i = MIN_DENORMAL_SP;
	return (w.r);
    }
    else if ( isnan(x) || isinf(x) )
	return *x;
    else if ( (*x < 0.0) && (setxp(x,&zero) == -half) )
    {					/* special boundary case */
	w.r = setxp(&half,(n--, &n));
	if (w.r == 0.0)			/* then x = -1.17549e-38 80800000 */
	    w.i = MIN_DENORMAL_SP;	/* and setxp() -> 0, so fix up */
	return (w.r);
    }
    else
	return (setxp(&half,&n));
}
