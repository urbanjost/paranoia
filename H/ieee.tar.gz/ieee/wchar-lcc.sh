#! /bin/sh
# Test lcc with wide char data types.
# [20-Mar-2001]

LIBDIR=`dirname $0`
trap '/bin/rm -f wchar.o a.out'

echo ========================================================================
/bin/rm -f a.out &&
	 lcc -Wf-wchar_t=unsigned_char $LIBDIR/wchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ------------------------------------------------------------------------
/bin/rm -f a.out &&
	 lcc -Wf-wchar_t=unsigned_short $LIBDIR/wchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ------------------------------------------------------------------------
/bin/rm -f a.out &&
	 lcc -Wf-wchar_t=unsigned_int $LIBDIR/wchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ========================================================================
