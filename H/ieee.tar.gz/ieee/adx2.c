#include "ieeeftn.h"

#if STDC
REAL
adx(REAL *x, INTEGER *n)
#else /* NOT STDC */
REAL
adx(x,n)				/* return x * base**n */
REAL *x;
INTEGER *n;
#endif /* STDC */
{
    INTEGER delta_e;
    INTEGER e;
    REAL_PARTS w;
    REAL new_x;

    w.r = *x;
    e = GET_EXPONENT_SP(w.i);		/* extract old exponent */

    if (*x == 0.0)			/* zero remains unchanged */
	/* NO-OP */;
    else if (e == EXPONENT_INFNAN_SP)	/* original number is NaN or Inf */
	/* NO-OP */;			/* so no change in value */
    else if (e == EXPONENT_DENORM_SP)	/* original number is denormalized */
    {
	delta_e = *n - T_SP;
	new_x = *x * BASE_TO_THE_T_SP;	/* scale into normal range */
	w.r = adx(&new_x, &delta_e);
    }
    else				/* original number is normal */
    {
	e += *n;			/* new exponent */
	w.r = setxp(x,&e);
    }
    return (w.r);
}
