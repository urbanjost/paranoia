#include "ieeeftn.h"

#if STDC
DOUBLEPRECISION
deps(DOUBLEPRECISION *x)
#else /* NOT STDC */
DOUBLEPRECISION
deps(x)
DOUBLEPRECISION	*x;
#endif /* STDC */
{
    DOUBLEPRECISION		half = 0.5;
    INTEGER			n = dintxp(x) - T_DP;
    INTEGER			zero = 0;
    DOUBLEPRECISION_PARTS	w;

    if ( (*x == 0.0) || disden(x) )
    {
	w.i[DP_HIGH] = MIN_DENORMAL_DP;
	w.i[DP_LOW] = MIN_DENORMAL_Low_DP;
	return (w.r);
    }
    else if ( disnan(x) || disinf(x) )
	return *x;
    else if ( (*x < 0.0) && (dsetxp(x,&zero) == -half) )
    {					/* special boundary case */
	w.r = dsetxp(&half,(n--, &n));
	if (w.r == 0.0)		/* then x = 2.22507e-308 0x00000000 00100000 */
	{
	    w.i[DP_HIGH] = MIN_DENORMAL_DP; /* and setxp() -> 0, so fix up */
	    w.i[DP_LOW] = MIN_DENORMAL_Low_DP;
	}
	return (w.r);
    }
    else
	return (dsetxp(&half,&n));
}
