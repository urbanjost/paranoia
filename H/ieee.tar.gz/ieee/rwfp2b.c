/***********************************************************************
Read floating-point numbers from stdin (one per line), and output
then on stdout in 32-bit, 64-bit, 80-bit, and 128-bit floating-point,
in hexadecimal and decimal.

This version uses %lle for long double format items.
[28-Nov-2001]
***********************************************************************/

#if defined(HAVE_LONG_DOUBLE)
typedef long double LONG_DOUBLE;
#else
typedef double LONG_DOUBLE;
#endif

#include <stdio.h>
#include <stdlib.h>
#include "args.h"

int
main(VOID_ARG)
{
    union
    {
	unsigned int ix[1];
	float x;
    }
    s;

    union
    {
	unsigned int ix[2];
	double x;
    }
    d;
    union
    {
	unsigned short is[8];
	unsigned int ix[4];
	LONG_DOUBLE x;
    }
    q;
    int i;
    int big_endian;

    if (sizeof(LONG_DOUBLE) == sizeof(double))
	(void)printf("WARNING: On this system, long double is a synonym for double, sigh...\n");
    d.x = 1.0;
    big_endian = (d.ix[0] != 0);
    for (i = 0; i < 4; ++i)
	q.ix[i] = 0xdeadbeefL;

    while (scanf("%le", &d.x) == 1)	
    { /* we input double instead of long double to work around library limitations */
	s.x = (float)d.x;
	q.x = (LONG_DOUBLE)d.x;
	(void)printf(" 32-bit: %08x                           %45.8e\n", s.ix[0], s.x);
	if (big_endian)
	{
	    (void)printf(" 64-bit: %08x%08x                   %45.17le\n", d.ix[0], d.ix[1], d.x);
	    (void)printf(" 80-bit: %04hx%04hx%04hx%04hx%04hx               %45.21lle\n",
			 q.is[0], q.is[1], q.is[2], q.is[3], q.is[4], q.x);
	    (void)printf("128-bit: %08x%08x%08x%08x   %45.35lle\n",
			 q.ix[0], q.ix[1], q.ix[2], q.ix[3], q.x);
	}
	else
	{
	    (void)printf(" 64-bit: %08x%08x                   %45.17le\n", d.ix[1], d.ix[0], d.x);
	    (void)printf(" 80-bit: %04hx%04hx%04hx%04hx%04hx               %45.21lle\n",
			 q.is[4], q.is[3], q.is[2], q.is[1], q.is[0], q.x);
	    (void)printf("128-bit: %08x%08x%08x%08x   %45.35lle\n",
			 q.ix[3], q.ix[2], q.ix[1], q.ix[0], q.x);
	}
	(void)fflush(stdout);
    }

    return (EXIT_SUCCESS);
}
