#include "ieeeftn.h"

#if STDC
LOGICAL
isden(REAL *x)
#else /* NOT STDC */
LOGICAL
isden(x)			/* return (x is denormalized) */
REAL	*x;
#endif /* STDC */
{
    return (intxp(x) <= EXPONENT_DENORM_SP) ? _TRUE_ : _FALSE_;
}
