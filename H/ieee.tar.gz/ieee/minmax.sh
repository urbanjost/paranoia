#! /bin/sh
### ====================================================================
### Test the minmax.f Fortran program with all known compilers.
### [28-Nov-2001]
### ====================================================================

mywhich()
{
	case $1 in
		/*)		# Handle absolute path case separately
			test -f $1 && echo "$@" && return
			;;
		*)		# else search PATH
			for d in ` echo $PATH | sed -e 's/:/ /g' `
			do
				test -f $d/$1 && echo $d/"$@" && return
			done
			echo ""
			;;
	esac
}

os=`uname -s`
arch=`uname -m`

for FC in \
	f77 g77 f90 f95 fort lf95 "nagf90 -ieee=full" "nagf95 -ieee=full" \
	pgf77 pgf90 pghpf sgif90 xlf xlf90 xlf95
do
	FFLAGS=
	case $os in
	AIX)
		case $FC in
		xlf90)	FFLAGS=-qfixed ;;
		xlf95)	FFLAGS=-qfixed ;;
		esac
		;;
	Linux)
		case $arch in
		alpha)
			case $FC in
			fort)	FFLAGS=-fpe3 ;;
			*)	FFLAGS=-mieee ;;
			esac
			;;
		esac
		;;
	OSF1)
		case $FC in
		f77)	FFLAGS=-fpe3 ;;
		f90)	FFLAGS=-fpe3 ;;
		f95)	FFLAGS=-fpe3 ;;
		g77)	FFLAGS=-mieee ;;
		esac
		;;
	SunOS)
		case $FC in
		f90)	FFLAGS="-ftrap=%none" ;;
		f95)	FFLAGS="-ftrap=%none" ;;
		esac
		;;
	esac

	/bin/rm -f ./a.out 1>/dev/null 2>&1
	if test ! -z "`mywhich $FC`"
	then
		echo "------------------------------------------------------------------------"
		echo Architecture: `$HOME/bin/machinetype || uname -a || true`

		echo "$FC -g $FFLAGS minmax.f"
		$FC -g $FFLAGS minmax.f 1>/dev/null 2>&1 && ./a.out 2>/dev/null
	fi
done
