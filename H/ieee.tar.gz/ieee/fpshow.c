/***********************************************************************
Print a number of important constants in decimal and hexadecimal to
check internal representations on a new machine.

[20-Feb-1994]
***********************************************************************/

#include <stdio.h>
#include "ieeeftn.h"

void dshow ARGS((double));
void show ARGS((float));

int
main(VOID_ARG)
{
    static double den      = 0.0;
    static float Eps       = 1.192092895507813e-07;
    static double Deps     = 1.110223024625157e-16;
    static float tinyflt   = 1.4012984643248170709237295832899161312802619418765E-45;
    static float minflt    = 1.1754943508222875079687365372222456778186655567721E-38;
    static float maxflt    = 3.40282346638528859811704183484516925440e+38;
    static double dtinyflt = 4.9406564584124654417656879286822137236505980261432E-324;
    static double dminflt  = 2.2250738585072013830902327173324040642192159804623E-308;
    static double dmaxflt  = 1.7976931348623157081452742373170435679807056752585E+308;

    (void)printf("Single precision\n");
    show(0.0);
    show(1.0);
    show(-1.0);
    show(2.0);
    show(-2.0);
    show(Eps);
    show(-Eps);
    show(tinyflt);
    show(-tinyflt);
    show(minflt);
    show(-minflt);
    show(maxflt);
    show(-maxflt);
    show(1.0/den);
    show(-1.0/den);
    show(0.0/den);

    (void)printf("\nDouble precision\n");
    dshow(0.0);
    dshow(1.0);
    dshow(-1.0);
    dshow(2.0);
    dshow(-2.0);
    dshow(Deps);
    dshow(-Deps);
    dshow(dtinyflt);
    dshow(-dtinyflt);
    dshow(dminflt);
    dshow(-dminflt);
    dshow(dmaxflt);
    dshow(-dmaxflt);
    dshow(1.0/den);
    dshow(-1.0/den);
    dshow(0.0/den);

    exit (EXIT_SUCCESS);
    return (EXIT_SUCCESS);
}

#if STDC
void
dshow(double x)
#else /* NOT STDC */
void
dshow(x)
double x;
#endif
{
    DOUBLEPRECISION_PARTS X;
    X.r = x;
    (void)printf("\t%16lg\t0x%08lx %08lx\n",
		 X.r,
		 (unsigned long)X.i[0],
		 (unsigned long)X.i[1]);
}

#if STDC
void
show(float x)
#else /* NOT STDC */
void
show(x)
float x;
#endif /* STDC */
{
    REAL_PARTS X;
    X.r = x;
    (void)printf("\t%16g\t0x%08lx\n", X.r, (unsigned long)X.i);
}
