#include "ieeeftn.h"

#if STDC
LOGICAL
isinf(REAL *x)
#else /* NOT STDC */
LOGICAL
isinf(x)
REAL *x;
#endif /* STDC */
{
    REAL_PARTS w;

    w.r = *x;
    return (((GET_EXPONENT_SP(w.i) == EXPONENT_INFNAN_SP) &&
	     (SIGNIFICAND_SP(w.i) == 0))
	    ? _TRUE_ : _FALSE_);
}
