/***********************************************************************
Print the return values of the Standard C isxxx() functions for every
character in the 256-character set.
[20-Feb-1994]
***********************************************************************/

#include <stdio.h>
#include <ctype.h>
#include "ieeeftn.h"

#if STDC
#define PRTLOG(xxx)     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)putchar(is ## xxx(k) ? 'T' : 'F');\
	(void)putchar('\n');\
	} while (0)

#define PRTINT(xxx)     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)printf("%4d",to ## xxx(k));\
	(void)putchar('\n');\
	} while (0)
#else /* NOT STDC */
#define PRTLOG(xxx)     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)putchar(is/**/xxx(k) ? 'T' : 'F');\
	(void)putchar('\n');\
	} while (0)

#define PRTINT(xxx)     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)printf("%4d",to/**/xxx(k));\
	putchar('\n');\
	} while (0)
#endif /* STDC */

#define PRTLOWER     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)printf("%4d",isupper(k) ? tolower(k) : k);\
	(void)putchar('\n');\
	} while (0)

#define PRTUPPER     do {\
	for (k = 0; k <= 255; ++k)\
	    (void)printf("%4d",islower(k) ? toupper(k) : k);\
	(void)putchar('\n');\
	} while (0)

#if STDC
int
main(int argc, char *argv[])
#else /* NOT STDC */
int
main(argc,argv)
int argc;
char* argv[];
#endif /* STDC */
{
    int k;

    (void)fputs("isalnum: ",stdout);
    PRTLOG(alnum);
    (void)fputs("isalpha: ",stdout);
    PRTLOG(alpha);
    (void)fputs("isascii: ",stdout);
    PRTLOG(ascii);
    (void)fputs("iscntrl: ",stdout);
    PRTLOG(cntrl);
    (void)fputs("isdigit: ",stdout);
    PRTLOG(digit);
    (void)fputs("isgraph: ",stdout);
    PRTLOG(graph);
    (void)fputs("islower: ",stdout);
    PRTLOG(lower);
    (void)fputs("isprint: ",stdout);
    PRTLOG(print);
    (void)fputs("ispunct: ",stdout);
    PRTLOG(punct);
    (void)fputs("isspace: ",stdout);
    PRTLOG(space);
    (void)fputs("isupper: ",stdout);
    PRTLOG(upper);
    (void)fputs("isxdigit: ",stdout);
    PRTLOG(xdigit);
    (void)fputs("toascii: ",stdout);
    PRTINT(ascii);
    (void)fputs("tolower: ",stdout);
    PRTLOWER;
    (void)fputs("toupper: ",stdout);
    PRTUPPER;
    exit (EXIT_SUCCESS);
    return (EXIT_SUCCESS);
}
