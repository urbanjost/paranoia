#if defined(HAVE_LONG_DOUBLE)
typedef long double LONG_DOUBLE;
#else
typedef double LONG_DOUBLE;
#endif

#include <stdio.h>
#include "args.h"

int
main(VOID_ARG)
{
    float f1, f2;
    double d1, d2;
    LONG_DOUBLE q1, q2;

    f1 = (float)0.0;
    f2 = -f1;

    d1 = (double)0.0;
    d2 = -d1;

    q1 = (LONG_DOUBLE)0.0;
    q2 = -q1;

    (void)printf("float       comparision of 0 vs -0: %s\n", (f1 == f2) ? "OKAY" : "WRONG");
    (void)printf("double      comparision of 0 vs -0: %s\n", (d1 == d2) ? "OKAY" : "WRONG");
    (void)printf("long double comparision of 0 vs -0: %s\n", (q1 == q2) ? "OKAY" : "WRONG");

    return (EXIT_SUCCESS);
}
