#! /bin/sh
### Test the C compiler defined by the CC environment variable (default: cc)
### for support of wide characters.
### [21-Mar-2001]

LIBDIR=`dirname $0`
trap '/bin/rm -f wchar.o a.out'

test -z "$CC" && CC=cc

echo ========================================================================
/bin/rm -f a.out &&
	 $CC $LIBDIR/wchar.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ========================================================================
