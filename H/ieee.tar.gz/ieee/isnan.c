#include "ieeeftn.h"

#if STDC
LOGICAL
isnan(REAL *x)
#else /* NOT STDC */
LOGICAL
isnan(x)
REAL *x;
#endif /* STDC */
{
#if defined(__alpha)
    if (isden(x))
	return (_FALSE_);
    else
	return ((*x != *x) ? _TRUE_ : _FALSE_);
#else
    return ((*x != *x) ? _TRUE_ : _FALSE_);
#endif
}
