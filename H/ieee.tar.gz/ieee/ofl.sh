#! /bin/sh
# Test lcc with IEEE 754 floating-point Infinity and NaN values.
# [21-Mar-2001]

LIBDIR=`dirname $0`
trap '/bin/rm -f ofl.o a.out'

echo ========================================================================
/bin/rm -f a.out &&
	 lcc $LIBDIR/ofl.c &&
	 ./a.out &&
	 /bin/rm -f a.out 
echo ========================================================================
